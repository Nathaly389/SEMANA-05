/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.conversortemperatura;

/**
 *
 * @author PERSONAL
 */
public class ConversorTemperatura {

    public static void main(String[] args) {
        // Variable de tipo float para la temperatura en Celsius
        float temperatura_celsius = 25.0f;

        // Variable para guardar la conversión
        float temperatura_fahrenheit;

        // Mensaje que se va a mostrar
        String mensaje = "La temperatura en Fahrenheit es:";

        // Controla si se muestra o no el resultado
        boolean mostrar_resultado = true;

        // Conversión de grados Celsius a Fahrenheit
        temperatura_fahrenheit = (temperatura_celsius * 9 / 5) + 32;

        // Mostrar el resultado si mostrar_resultado es true
        if (mostrar_resultado) {
            System.out.println(mensaje + " " + temperatura_fahrenheit + "°F");
        }
    }
}